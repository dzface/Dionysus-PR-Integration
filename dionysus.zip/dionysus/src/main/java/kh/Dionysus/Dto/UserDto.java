package kh.Dionysus.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
    private String user_id;
    private String user_pw;
    private String user_name;
    private String user_jumin;
    private String user_nick;
    private String user_phone;
    private String user_address;
}
