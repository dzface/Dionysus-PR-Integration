package kh.Dionysus.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JjimDto {
    private String user_id;
    private String Alcohol_name;
    private boolean jjim;
}
