package kh.Dionysus.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScoreDto {
    private String user_id;
    private String alcohol_name;
    private int score;
}
