package kh.Dionysus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DionysusApplication {

	public static void main(String[] args) {
		SpringApplication.run(DionysusApplication.class, args);
	}

}
